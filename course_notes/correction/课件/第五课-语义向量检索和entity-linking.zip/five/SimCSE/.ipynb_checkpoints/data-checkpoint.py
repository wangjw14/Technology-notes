import os
import random
# from turtle import pos
import torch.utils.data as data
from transformers import BertTokenizer
import json
import numpy as np

class Supervised(data.Dataset):
    def __init__(self, dir="./data/") -> None:
        super(Supervised, self).__init__()
        self.data_dir = os.path.join(dir,'train.json')
        self.train_data = []
        self._create_train_data()
        self.company_dic = self.get_dic()
        self.tokenizer = BertTokenizer.from_pretrained(
            '../bert_model_data/')

    def get_dic(self,):
        dic = []
        with open(file="./data/股票名称.csv",encoding="utf-8",mode="r") as f:
            for i,line in enumerate(f):
                if i==0:
                    continue
                line = [x for x in line.strip().split("\t") if x!="不详" and x!="None" and x]
                dic+=line

        return dic

    def _create_train_data(self):
        data = json.load(open(self.data_dir, 'r', encoding='utf-8'))
        for item in data:
            source_company = item["source_company"]
            target_company = item["target_company"]
            self.train_data.append((source_company,target_company))



    def __getitem__(self, index):
        anchor_text, pos_text = self.train_data[index]
        neg_text = np.random.choice(self.company_dic)
        while neg_text==anchor_text or neg_text==pos_text:
            neg_text = np.random.choice(self.company_dic)

        sample = self._post_process(anchor_text, pos_text, neg_text)
        return sample

    def _post_process(self, anchor_text, pos_text, neg_text):
        sample = self.tokenizer([anchor_text, pos_text, neg_text],
                                truncation=True,
                                add_special_tokens=True,
                                max_length=15,
                                padding='max_length',
                                return_tensors='pt').to("cuda")

        return sample

    def __len__(self):
        return len(self.train_data)


class Infer():
    def __init__(self,model):
        self.tokenizer = BertTokenizer.from_pretrained('../bert_model_data')
        self.model = model

    def get_emb(self,text):
        text = list(text.strip())
        input = self.tokenizer.encode_plus(text,return_tensors='pt').to("cuda:0")
        emb = self.model.predict(input)
        return emb


    def __getitem__(self, index):
        text = self.all_data[index]


        return data,text.strip()

    def __len__(self):
        return len(self.all_data)

    def get_companys(self,):
        dic = []
        with open(file="./data/股票名称.csv",encoding="utf-8",mode="r") as f:
            for i,line in enumerate(f):
                if i==0:
                    continue
                line = [x for x in line.strip().split("\t") if x!="不详" and x!="None" and x]
                dic+=line

        return dic


if __name__ == '__main__':
    Supervised()