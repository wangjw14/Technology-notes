#python main.py train
#python main.py test

import os
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from data import Supervised,Infer
from model import TextBackbone
from datetime import datetime
import numpy as np
import logging
import transformers
from transformers import BertModel
from transformers import AdamW, get_linear_schedule_with_warmup
from torch.cuda.amp import autocast as ac
from tqdm import tqdm
from utils import swa,FGM,PGD
transformers.logging.set_verbosity_error()
logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)
import sys
mode = sys.argv[1]


def sup_loss(y_pred, lamda=0.05):
    row = torch.arange(0, y_pred.shape[0], 3, device="cuda")
    col = torch.arange(y_pred.shape[0], device="cuda")
    col = torch.where(col % 3 != 0)[0].cuda()
    y_true = torch.arange(0, len(col), 2, device="cuda")
    similarities = F.cosine_similarity(y_pred.unsqueeze(1), y_pred.unsqueeze(0), dim=2)
    similarities = torch.index_select(similarities, 0, row)
    similarities = torch.index_select(similarities, 1, col)
    similarities = similarities / lamda
    loss = F.cross_entropy(similarities, y_true)
    return torch.mean(loss)


def train(dataloader, model, optimizer, schedular, criterion, log_file, mode="unsup",attack_train=' '):
    if attack_train=='fgm':
        fgm = FGM(model=model)
    
    num = 2
    if mode == "sup":
        num = 3
    model.train()
    
    all_loss = []
    for idx, data in enumerate(dataloader):
        process_bar = '\r[training:%d/{}]'.format(len(dataloader))
        print(process_bar % idx, end='', flush=True)
        input_ids = data["input_ids"].view(len(data["input_ids"]) * num, -1).cuda()
        attention_mask = (
            data["attention_mask"].view(len(data["attention_mask"]) * num, -1).cuda()
        )
        token_type_ids = (
            data["token_type_ids"].view(len(data["token_type_ids"]) * num, -1).cuda()
        )
        pred = model(input_ids, attention_mask, token_type_ids)
        optimizer.zero_grad()
        loss = criterion(pred)

        all_loss.append(loss.item())
        loss.backward()
        
        if attack_train=='fgm':
            fgm.attack()
            adv_pred = model(input_ids, attention_mask, token_type_ids)
            optimizer.zero_grad()
            adv_loss = criterion(adv_pred)
            adv_loss.backward()
            fgm.restore()
        
        optimizer.step()
        schedular.step()

        if idx % 30 == 0:
            torch.cuda.empty_cache()
            with open(log_file, "a+") as f:
                t = sum(all_loss) / len(all_loss)
                info = str(idx) + " == {} == ".format(mode) + str(t) + "\n"
                f.write(info)
                all_loss = []

def prepare():
    os.makedirs("./output", exist_ok=True)
    now = datetime.now()
    log_file = now.strftime("%Y_%m_%d_%H_%M_%S") + "_log.txt"
    return "./output/" + log_file


if __name__ == "__main__":
    model = TextBackbone().cuda()
    if mode=="train":
        logger.info("make sup simcse train.....")
        log_file = prepare()
        dataset = Supervised()
        batch_size = 64
        logger.info("batch_size:{},train_num:{}".format(batch_size,len(dataset)))
        dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=False)
        param_optimizer = list(model.named_parameters())
        no_decay = ["bias", "LayerNorm.bias", "LayerNorm.weight"]
        optimizer_grouped_parameters = [
            {
                "params": [
                    p for n, p in param_optimizer if not any(nd in n for nd in no_decay)
                ],
                "weight_decay": 0.01,
            },
            {
                "params": [
                    p for n, p in param_optimizer if any(nd in n for nd in no_decay)
                ],
                "weight_decay": 0.0,
            },
        ]
        optimizer = AdamW(optimizer_grouped_parameters, lr=2e-5)
        epochs = 5
        num_train_steps = int(len(dataloader) * epochs)
        schedular = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=0.05 * num_train_steps,
            num_training_steps=num_train_steps,
        )

        criterion = sup_loss
        for epoch in range(1, epochs + 1):
            logger.info("Epoch:{}/{}\n".format(epoch,epochs))
            train(dataloader, model, optimizer, schedular, criterion, log_file, mode="sup")
            torch.save(model.state_dict(), "./output/sup_model.pt")

    else:
        logger.info("make predict....")
        model.load_state_dict(torch.load("./output/sup_model.pt",map_location="cpu"),strict=True)

        if os.path.exists("doc_embedding"):
            os.remove("doc_embedding")

        model.eval()
        infer = Infer(model)
        companys = infer.get_companys()
        with open(file="doc_embedding", mode="w",encoding="utf-8") as f:
            for text in tqdm(companys):
                emb = infer.get_emb(text).squeeze().detach().cpu().numpy().tolist()
                y = [str(round(i,8)) for i in emb]
                info = text.strip() + "\t"
                info = info + ",".join(y)
                f.write(info + "\n")