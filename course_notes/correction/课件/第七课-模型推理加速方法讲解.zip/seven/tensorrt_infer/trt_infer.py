import json
import time
import requests
import torch
import numpy as np
from transformers import BertTokenizer
import os
import pycuda.driver as cuda
import pycuda.autoinit
import tensorrt as trt
import numpy as np
import pdb
from utils import trt_engine,span_decode
import logging
logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)

class TensorRt_Infer():
    def __init__(self):
        self.init_base()
        self.init_trt()

    def init_base(self,):
        with open(file='../info_extract/data/span_ent2id.json',encoding='utf-8',mode='r') as f:
            ent2id = json.load(f)
        self.id2ent = {v: k for k, v in ent2id.items()}
        self.token = BertTokenizer.from_pretrained('../bert_model_data/vocab.txt')

    def init_trt(self,):
        logger.info("init trt engine......")
        self.trt = trt_engine()

    def trt_infer(self,text):
        encode_dict = self.token.encode_plus(text=list(text),
                                             is_pretokenized=True,
                                             max_length=12,
                                             pad_to_max_length=True,
                                             return_token_type_ids=True,
                                             return_attention_mask=True)

        feed_dict = {'input_ids': np.array([encode_dict["input_ids"]], dtype=np.int32),
                     'attention_mask': np.array([encode_dict["attention_mask"]], dtype=np.int32),
                     'token_type_ids': np.array([encode_dict["token_type_ids"]], dtype=np.int32)}

        trt_decode = self.trt.engine_infer(feed_dict)
        predict = span_decode(trt_decode,text,self.id2ent)
        return predict

if __name__ == "__main__":
    trt = TensorRt_Infer()
    demo = "长春高新的资金如何"
    res = trt.trt_infer(demo)
    print("{}\t{}".format(demo,res[0]))