import os
import numpy as np
import numpy as np
from subprocess import Popen, PIPE, STDOUT
import os
import argparse

IDCS = {'\u2ff0': 2,  # 12 ideographic description characters and their capacity of son nodes
        '\u2ff1': 2,
        '\u2ff2': 3,
        '\u2ff3': 3,
        '\u2ff4': 2,
        '\u2ff5': 2,
        '\u2ff6': 2,
        '\u2ff7': 2,
        '\u2ff8': 2,
        '\u2ff9': 2,
        '\u2ffa': 2,
        '\u2ffb': 2, }


PINYIN = {'ā': ['a', 1], 'á': ['a', 2], 'ǎ': ['a', 3], 'à': ['a', 4],
          'ē': ['e', 1], 'é': ['e', 2], 'ě': ['e', 3], 'è': ['e', 4],
          'ī': ['i', 1], 'í': ['i', 2], 'ǐ': ['i', 3], 'ì': ['i', 4],
          'ō': ['o', 1], 'ó': ['o', 2], 'ǒ': ['o', 3], 'ò': ['o', 4],
          'ū': ['u', 1], 'ú': ['u', 2], 'ǔ': ['u', 3], 'ù': ['u', 4],
          'ǖ': ['ü', 1], 'ǘ': ['ü', 2], 'ǚ': ['ü', 3], 'ǜ': ['ü', 4],
          '': ['m', 2], 'ń': ['n', 2], 'ň': ['n', 3], 'ǹ': ['n', 4],
          }


def edit_distance(string_a, string_b, name='Levenshtein'):
    size_x = len(string_a) + 1
    size_y = len(string_b) + 1
    matrix = np.zeros((size_x, size_y), dtype=int)
    for x in range(size_x):
        matrix[x, 0] = x
    for y in range(size_y):
        matrix[0, y] = y

    for x in range(1, size_x):
        for y in range(1, size_y):
            if string_a[x - 1] == string_b[y - 1]:
                matrix[x, y] = min(
                    matrix[x - 1, y] + 1,
                    matrix[x - 1, y - 1],
                    matrix[x, y - 1] + 1
                )
            else:
                if name == 'Levenshtein':
                    matrix[x, y] = min(
                        matrix[x - 1, y] + 1,
                        matrix[x - 1, y - 1] + 1,
                        matrix[x, y - 1] + 1
                    )
                else:  # Canonical
                    matrix[x, y] = min(
                        matrix[x - 1, y] + 1,
                        matrix[x - 1, y - 1] + 2,
                        matrix[x, y - 1] + 1
                    )

    return matrix[size_x - 1, size_y - 1]


class CharFuncs(object):
    def __init__(self, char_meta_fname):
        self.data = self.load_char_meta(char_meta_fname)
        self.char_dict = dict([(c, 0) for c in self.data])

        self.safe = {'\u2ff0': 'A',  # to eliminate the bug that, in Windows CMD, char ⿻ and ⿵ are encoded to be the same.
                     '\u2ff1': 'B',
                     '\u2ff2': 'C',
                     '\u2ff3': 'D',
                     '\u2ff4': 'E',
                     '\u2ff5': 'F',
                     '\u2ff6': 'G',
                     '\u2ff7': 'H',
                     '\u2ff8': 'I',
                     '\u2ff9': 'J',
                     '\u2ffa': 'L',
                     '\u2ffb': 'M',}

    @staticmethod
    def load_char_meta(fname):
        data = {}
        f = open(fname, 'r', encoding='utf-8')
        for line in f:
            items = line.strip().split('\t')
            code_point = items[0]
            char = items[1]
            pronunciation = items[2]
            decompositions = items[3:]
            assert char not in data
            data[char] = {"code_point": code_point, "pronunciation": pronunciation, "decompositions": decompositions}
        return data

    def shape_distance(self, char1, char2, safe=True, as_tree=False):
        assert char1 in self.data
        assert char2 in self.data

        def safe_encode(decomp):
            tree = ''
            for c in string_to_tree(decomp):
                if c not in self.safe:
                    tree += c
                else:
                    tree += self.safe[c]
            return tree

        def safe_encode_string(decomp):
            tree = ''
            for c in decomp:
                if c not in self.safe:
                    tree += c
                else:
                    tree += self.safe[c]
            return tree

        decomps_1 = self.data[char1]["decompositions"]
        decomps_2 = self.data[char2]["decompositions"]

        distance = 1e5
        if as_tree:
            for decomp1 in decomps_1:
                for decomp2 in decomps_2:
                    if not safe:
                        ted = tree_edit_distance(string_to_tree(decomp1), string_to_tree(decomp2))
                    else:
                        ted = tree_edit_distance(safe_encode(decomp1), safe_encode(decomp2))
                        distance = min(distance, ted)
        else:
            for decomp1 in decomps_1:
                for decomp2 in decomps_2:
                    if not safe:
                        ed = edit_distance(decomp1, decomp2)
                    else:
                        ed = edit_distance(safe_encode_string(decomp1), safe_encode_string(decomp2))
                    distance = min(distance, ed)

        return distance

    def pronunciation_distance(self, char1, char2):
        assert char1 in self.data
        assert char2 in self.data
        pronunciations1 = self.data[char1]["pronunciation"]
        pronunciations2 = self.data[char2]["pronunciation"]

        if pronunciations1[0] == 'null' or pronunciations2 == 'null':
            return 0.0
        else:

            pronunciations1 = pronunciations1.split(';')  # separate by lan
            pronunciations2 = pronunciations2.split(';')  # separate by lan

            distance = 0.0
            count = 0
            for pron_lan1, pron_lan2 in zip(pronunciations1, pronunciations2):
                if (pron_lan1 == 'null') or (pron_lan2 == 'null'):
                    pass
                else:
                    distance_lan = 1e5
                    for p1 in pron_lan1.split(','):
                        for p2 in pron_lan2.split(','):
                            distance_lan = min(distance_lan, edit_distance(p1, p2))
                    distance += distance_lan
                    count += 1

            return distance / count

    @staticmethod
    def load_dict(fname):
        data = {}
        f = open(fname, 'r', encoding='utf-8')
        for line in f:
            char, freq = line.strip().split('\t')
            assert char not in data
            data[char] = freq

        return data

    def similarity(self, char1, char2, weights=(0.8, 0.2, 0.0), as_tree=False):

        shape_w, sound_w, freq_w = weights

        if char1 in self.char_dict and char2 in self.char_dict:

            shape_sim = self.shape_similarity(char1, char2, as_tree=as_tree)
            sound_sim = self.pronunciation_similarity(char1, char2)
            freq_sim = 1.0 - self.char_dict[char2] / len(self.char_dict)

            return shape_sim * shape_w + sound_sim * sound_w + freq_sim * freq_w
        else:
            return 0.0

    def shape_similarity(self, char1, char2, safe=True):

        def safe_encode(decomp):
            tree = ''
            for c in string_to_tree(decomp):
                if c not in self.safe:
                    tree += c
                else:
                    tree += self.safe[c]
            return tree

        def safe_encode_string(decomp):
            tree = ''
            for c in decomp:
                if c not in self.safe:
                    tree += c
                else:
                    tree += self.safe[c]
            return tree

        decomps_1 = [self.data[x]["decompositions"][0] if x in self.data else x for x in list(char1)]
        decomps_1 = ["".join(decomps_1)]
        decomps_2 = [self.data[x]["decompositions"][0] if x in self.data else x for x in list(char2)]
        decomps_2 = ["".join(decomps_2)]
        

        similarity = 0.0
        for decomp1 in decomps_1:
            for decomp2 in decomps_2:
                if not safe:
                    ed = edit_distance(decomp1, decomp2)
                else:
                    ed = edit_distance(safe_encode_string(decomp1), safe_encode_string(decomp2))
                normalized_ed = ed / max(len(decomp1), len(decomp2))
                similarity = max(similarity, 1 - normalized_ed)

        return similarity

    def pronunciation_similarity(self, char1, char2):
        pronunciations1 = [self.data[x]["pronunciation"].split(";")[0].split(",")[0] if x in self.data else x for x in list(char1)]
        pronunciations1 = "".join(pronunciations1)
        pronunciations2 = [self.data[x]["pronunciation"].split(";")[0].split(",")[0] if x in self.data else x for x in list(char2)]
        pronunciations2 = "".join(pronunciations2)
        pingyin_sim = 1-edit_distance(pronunciations1,pronunciations2) / max(len(pronunciations1),len(pronunciations2))
        return pingyin_sim
            


def pinyin_map(standard_pinyin):
    """
    >>> pinyin_map('xuě')
    'xue3'
    >>> pinyin_map('xue')
    'xue'
    >>> pinyin_map('lǜ')
    'lü4'
    >>> pinyin_map('fá')
    'fa2'
    """
    tone = ''
    pinyin = ''

    assert ' ' not in standard_pinyin
    for c in standard_pinyin:
        if c in PINYIN:
            pinyin += PINYIN[c][0]
            assert tone == ''
            tone = str(PINYIN[c][1])
        else:
            pinyin += c
    pinyin += tone
    return pinyin
    
    

def generate_input(text,tokenizer):
    input_ids,token_type_ids,attention_mask = [],[],[]
    encode_dict = tokenizer.encode_plus(text=list(text),
                                        pad_to_max_length=True,
                                        is_pretokenized=True,
                                        return_token_type_ids=True,
                                        return_attention_mask=True,
                                        return_tensors='pt').to("cuda")
    return encode_dict


def span_decode(start_logits, end_logits, raw_text, id2ent):
    predict=[]
    start_pred = np.argmax(start_logits, -1)
    end_pred = np.argmax(end_logits, -1)

    for i, s_type in enumerate(start_pred):
        if s_type == 0:
            continue
        for j, e_type in enumerate(end_pred[i:]):
            if s_type == e_type:
                tmp_ent = raw_text[i:i + j + 1]
                predict.append((''.join(tmp_ent),i,i+j,s_type))
                break
    tmp = []
    for item in predict:
        if not tmp:
            tmp.append(item)
        else:
            if item[1]>tmp[-1][2]:
                tmp.append(item)
    res = []
    for ent,_,_,_ in tmp:
        res.append(ent)

    return res