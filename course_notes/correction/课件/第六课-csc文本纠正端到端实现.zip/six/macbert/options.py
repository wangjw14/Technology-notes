import argparse

class Args:
    @staticmethod
    def parse():
        parser = argparse.ArgumentParser()
        return parser

    @staticmethod
    def initialize(parser: argparse.ArgumentParser):
        # args for path
        parser.add_argument('--bert_dir', default='../bert_model_data/',
                            help='the dir of bert weights')

        parser.add_argument('--model_name', default='bert4csc',
                            help='model for macbert4csc')

        parser.add_argument('--hyper_params', default=0.2,
                            help='params for model')

        parser.add_argument('--train_data', default='output/train.json',
                            help='train data for model')

        parser.add_argument('--valid_data', default='output/dev.json',
                            help='valid data for model')

        parser.add_argument('--test_data', default='output/test.json',
                            help='valid data for model')

        # other args
        parser.add_argument('--seed', type=int, default=123, help='random seed')

        parser.add_argument('--gpu_ids', type=str, default=['0'],
                            help='gpu ids to use, -1 for cpu, "0,1" for multi gpu')
        # train args
        parser.add_argument('--train_epochs', default=10, type=int,
                            help='Max training epoch')

        parser.add_argument('--dropout_prob', default=0.1, type=float,
                            help='drop out probability')

        parser.add_argument("--mode", default="train",help="train or test",type=str)

        parser.add_argument('--lr', default=2e-5, type=float,
                            help='learning rate for the bert module')

        parser.add_argument('--other_lr', default=2e-3, type=float,
                            help='learning rate for the module except bert')

        parser.add_argument('--max_grad_norm', default=1.0, type=float,
                            help='max grad clip')

        parser.add_argument('--warmup_proportion', default=0.1, type=float)

        parser.add_argument('--weight_decay', default=0.01, type=float)

        parser.add_argument('--adam_epsilon', default=1e-8, type=float)

        parser.add_argument('--train_batch_size', default=32, type=int)

        parser.add_argument('--output_dir', default='output/bert4csc',type=str)
        
        parser.add_argument('--use_fp16', default=True, action='store_true',
                            help='weather to use fp16 during training')


        return parser

    def get_parser(self):
        parser = self.parse()
        parser = self.initialize(parser)
        return parser.parse_args()
