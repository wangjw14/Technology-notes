export LD_LIBRARY_PATH=/hy-tmp/TensorRT-8.0.0.3/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/hy-tmp/TensorRT-7.2.3.4/lib:$LD_LIBRARY_PATH
export LIBRARY_PATH=/hy-tmp/TensorRT-8.0.0.3/lib:$LIBRARY_PATH
