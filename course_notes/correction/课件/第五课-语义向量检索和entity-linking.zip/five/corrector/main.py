# import faiss
import torch
import sys
sys.path.append("..")
import numpy as np
from transformers import BertTokenizer
from SimCSE.model import TextBackbone
from info_extract.src.utils.options import Args
from info_extract.src.utils.model_utils import build_model
from utils import generate_input,span_decode,CharFuncs
import logging
import json
import os
import torch
import pdb
import faiss



logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)


class Correction():
    def __init__(self,):
        self.init_ner()
        self.init_simcse()
        self.dim = 128
        self.init_index()
        self.char_feature = CharFuncs('../config_files/char_meta.txt')

    def init_ner(self,):
        logger.info("init ner model......")
        opt = Args().get_parser()
        self.tokenizer = BertTokenizer.from_pretrained('../bert_model_data')
        with open('../info_extract/data/span_ent2id.json', encoding='utf-8') as f:
            self.ent2id = json.load(f)
            self.id2ent = {v:k for k,v in self.ent2id.items()}
        self.ner_model = build_model('span', opt.bert_dir, opt, num_tags=len(self.ent2id) + 1,
                            dropout_prob=opt.dropout_prob,
                            loss_type=opt.loss_type)
        self.ner_model.load_state_dict(torch.load("../info_extract/out/best_model.pt", map_location="cpu"), strict=True)
        self.ner_model.cuda()
        self.ner_model.eval()



    def init_simcse(self,):
        logger.info("init simcse model......")
        self.simcse_model = TextBackbone(pretrained='../bert_model_data').cuda()
        self.simcse_model.load_state_dict(torch.load("../SimCSE/output/sup_model.pt", map_location="cpu"), strict=True)
        self.simcse_model.cuda()
        self.simcse_model.eval()

    def simcse_get_emb(self, text):
        text = list(text.strip())
        input = self.tokenizer.encode_plus(text, return_tensors='pt').to("cuda:0")
        emb = self.simcse_model.predict(input)
        return emb

    def faiss_search(self,text,k=15):
        emb = self.simcse_get_emb(text).squeeze().detach().cpu().numpy().tolist()
        emb = np.array([emb],dtype="float32")
        _,results = self.index.search(emb,k)
        ents = [self.stock_name[int(x)] for x in results[0]]
        res,score = self.Ranking(text,ents)
        return res,score
    
    def ner_predict(self,text):
        inputs = generate_input(text,self.tokenizer)
        decode_output = self.ner_model(**inputs)
        start_logits = decode_output[0].detach().cpu().numpy()[0][1:-1]
        end_logits = decode_output[1].detach().cpu().numpy()[0][1:-1]
        predict = span_decode(start_logits,end_logits,text,self.id2ent)
        return predict
    
    def Ranking(self,ent,candidates):
        max_score,best_res = 0,None
        for candi in candidates:
            shape_score =  self.char_feature.shape_similarity(ent,candi) 
            pingyin_score = self.char_feature.pronunciation_similarity(ent,candi)
            score = shape_score*0.5 + pingyin_score*0.5
            if score > max_score:
                max_score = score
                best_res = candi

        return best_res,max_score
        


    def init_index(self):
        logger.info("build faiss index......")
        embeddings = []
        texts = []
        with open(file="../SimCSE/doc_embedding", encoding="utf-8", mode="r") as f:
            for line in f:
                text, emb = line.strip().split("\t")
                emb = [float(x) for x in emb.strip().split(",")]
                assert len(emb) == self.dim
                embeddings.append(emb)
                texts.append(text)
        embeddings = np.array(embeddings, dtype="float32")
        text2emb = {k: v for k, v in zip(texts, embeddings)}
        self.index = faiss.IndexFlatL2(self.dim)
        self.index.add(embeddings)
        self.stock_dic = set(texts)
        self.stock_name = texts
    
    def correct(self,text):
        res = self.ner_predict(text)
        if not res:
            return text
        for item in res:
            if item in self.stock_dic:
                new_item = item
            else:
                new_item,score = self.faiss_search(item)
            text = text.replace(item,new_item,1)
        return text




        
if __name__ == '__main__':
    corr = Correction()
    with open(file="./demo.txt",mode="r",encoding="utf-8") as f:
        for line in f:
            t = line.strip()
            new_t = corr.correct(t)
            print("{}\t{}".format(t,new_t))








