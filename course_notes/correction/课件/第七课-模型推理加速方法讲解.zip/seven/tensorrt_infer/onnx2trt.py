import tensorrt as trt
import onnx
import logging

logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)

# TRT_LOGGER = trt.Logger(trt.Logger.VERBOSE)
TRT_LOGGER = trt.Logger(trt.Logger.INFO)

def build_engine_from_onnx(model_file):
    with trt.Builder(TRT_LOGGER) as builder, \
            builder.create_network(1) as network, \
            builder.create_builder_config() as config, \
            trt.OnnxParser(network, TRT_LOGGER) as parser:
        with open(model_file, 'rb') as model:
            if not parser.parse(model.read()):
                for error in range(parser.num_errors):
                    logger.info(parser.get_error(error))
                return None
        # builder.fp16_mode = False
        profile = builder.create_optimization_profile()

        profile.set_shape('input_ids', (1, 1), (1, 12), (1, 20))
        profile.set_shape('attention_mask', (1, 1), (1, 12), (1, 20))
        profile.set_shape('token_type_ids', (1, 1), (1, 12), (1, 20))

        for _ in range(2):  # 设置2个profile即可
            config.add_optimization_profile(profile)

        config.max_workspace_size = 1 << 30  # 用来设置最大可使用显存大小
        # config.set_flag(trt.BuilderFlag.FP16)      # 这个参数用来控制是否使用FP16

        return builder.build_engine(network, config)


def convert(model_in_path, model_out_path):
    with build_engine_from_onnx(model_in_path) as engine:
        with open(model_out_path, 'wb') as f:
            f.write(engine.serialize())

    logger.info('Done!')


if __name__ == '__main__':
    convert('model.onnx', 'model.trt')
