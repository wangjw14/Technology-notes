# -*- coding: utf-8 -*-
import os
import sys
import torch
from options import Args
from transformers import BertTokenizer, BertForMaskedLM
import argparse
from collections import OrderedDict
import json
from torch.cuda.amp import autocast as ac
import copy
from loguru import logger
sys.path.append('../..')

from reader import make_loaders, DataCollator
from bert4csc import Bert4Csc
from utils import build_optimizer_and_scheduler
from transformers import AdamW, get_linear_schedule_with_warmup
from utils import model_evaluate,save_model
import logging
from tqdm import tqdm


def train_process(args):
    tokenizer = BertTokenizer.from_pretrained(args.bert_dir)
    collator = DataCollator(tokenizer=tokenizer)
    train_loader, valid_loader, test_loader = make_loaders(collator, train_path=args.train_data,
                                                           valid_path=args.valid_data, test_path=args.test_data,
                                                           batch_size=args.train_batch_size)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = Bert4Csc(args,tokenizer).to(device)
    t_total = len(train_loader) * args.train_epochs
    optimizer, scheduler = build_optimizer_and_scheduler(args, model, t_total)
    
    scaler = None
    if args.use_fp16:
        scaler = torch.cuda.amp.GradScaler()

    model.zero_grad()
    os.makedirs(args.output_dir, exist_ok=True)
    best_score = 0
    avg_loss = 0.
    
    fgm, pgd = None, None

    # attack_train_mode = args.attack_train.lower()
    # if attack_train_mode == 'fgm':
    #     fgm = FGM(model=model)
    # elif attack_train_mode == 'pgd':
    #     pgd = PGD(model=model)
    #     pgd_k = 3

    
    for epoch in range(args.train_epochs):
        torch.cuda.empty_cache()
        model.train()
        for batch,batch_data in enumerate(tqdm(train_loader)):
            batch_data["device"] = device
            
            if args.use_fp16:
                with ac():
                    loss = model(**batch_data)[0]
            else:
                loss = model(**batch_data)[0]
            
            if args.use_fp16:
                scaler.scale(loss).backward()
            else:
                loss.backward()
            
            if args.use_fp16:
                scaler.unscale_(optimizer)
            
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            
            if args.use_fp16:
                scaler.step(optimizer)
                scaler.update()
            else:
                optimizer.step()
            
            
            scheduler.step()
            model.zero_grad()
            avg_loss += loss.item()

        detect_f1, correct_f1, final_score = model_evaluate(model,device,args)
        logger.info('epoch {}\{},avg_loss:{}'.format(epoch+1,args.train_epochs,round(avg_loss,4)))
        if final_score > best_score:
            best_score = final_score
            best_model = copy.deepcopy(model)
            save_model(args,best_model,epoch)
            avg_loss = 0.
        logger.info('detect_f1:{} correct_f1:{} final_score:{} best_score:{}'.format(round(detect_f1,4),round(correct_f1,4),round(final_score),round(best_score,4)))

        # clear cuda cache to avoid OOM
    torch.cuda.empty_cache()
    logger.info('Train done')


if __name__ == '__main__':
    args = Args().get_parser()
    train_process(args)
