# encoding:utf-8

import numpy as np
from transformers import BertTokenizer, BertForMaskedLM
from bert4csc import Bert4Csc
from transformers import AdamW, get_linear_schedule_with_warmup
import torch
import re
from loguru import logger
import jieba
from torch.utils.data import Dataset
from tqdm import tqdm
import json
from pathlib import Path
import os
import Levenshtein
from string import punctuation as en_pun
from zhon.hanzi import punctuation as zh_pun


class MyToken():
    def __init__(self,):
        self.dic = self.get_dic()
        for w in self.dic:
            jieba.add_word(w)

    def get_dic(self,):
        dic = []
        with open(file="../raw_data/股票名称.csv",encoding="utf-8",mode="r") as f:
            for i,line in enumerate(f):
                if i==0:
                    continue
                line = [x for x in line.strip().split("\t") if x!="不详" and x!="None" and x]
                dic+=line

        dic = set([x.lower() for x in dic if "ST" in x]+dic)

        return dic

    def my_cut(self,text):
        res = [x for x in jieba.lcut(text) if x in self.dic]
        return res


class Inference:
    def __init__(self, ckpt_path='output/macbert4csc/best_model.ckpt',
                 vocab_path='../bert_model_data/pre_bert/torch_roberta_wwm',
                 cfg_path='train_macbert4csc.yml'):
        self.tokenizer = BertTokenizer.from_pretrained(vocab_path)
        cfg.merge_from_file(cfg_path)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        if 'macbert4csc' in cfg_path:
            self.model = MacBert4Csc.load_from_checkpoint(checkpoint_path=ckpt_path,
                                                          cfg=cfg,
                                                          map_location=self.device,
                                                          tokenizer=self.tokenizer,strict=True)
        elif 'softmaskedbert4csc' in cfg_path:
            self.model = SoftMaskedBert4Csc.load_from_checkpoint(checkpoint_path=ckpt_path,
                                                                 cfg=cfg,
                                                                 map_location=device,
                                                                 tokenizer=self.tokenizer)
        else:
            raise ValueError("model not found.")
        self.model.to(self.device)
        self.model.eval()

    def predict(self, sentence_list):
        """
        文本纠错模型预测
        Args:
            sentence_list: list
                输入文本列表
        Returns: tuple
            corrected_texts(list)
        """
        is_str = False
        if isinstance(sentence_list, str):
            is_str = True
            sentence_list = [sentence_list]
        corrected_texts = self.model.predict(sentence_list)
        if is_str:
            return corrected_texts[0]
        return corrected_texts

    def predict_with_error_detail(self, sentence_list):
        """
        文本纠错模型预测，结果带错误位置信息
        Args:
            sentence_list: list
                输入文本列表
        Returns: tuple
            corrected_texts(list), details(list)
        """
        details = []
        is_str = False
        if isinstance(sentence_list, str):
            is_str = True
            sentence_list = [sentence_list]
        corrected_texts = self.model.predict(sentence_list)

        for corrected_text, text in zip(corrected_texts, sentence_list):
            corrected_text, sub_details = get_errors(corrected_text, text)
            details.append(sub_details)
        if is_str:
            return corrected_texts[0], details[0]
        return corrected_texts, details


def build_optimizer_and_scheduler(opt, model, t_total):
    module = (
        model.module if hasattr(model, "module") else model
    )

    # 差分学习率
    no_decay = ["bias", "LayerNorm.weight"]
    model_param = list(module.named_parameters())

    bert_param_optimizer = []
    other_param_optimizer = []

    for name, para in model_param:
        space = name.split('.')
        if 'bert' in space:
            bert_param_optimizer.append((name, para))
        else:
            other_param_optimizer.append((name, para))


    optimizer_grouped_parameters = [
        # bert other module
        {"params": [p for n, p in bert_param_optimizer if not any(nd in n for nd in no_decay)],
         "weight_decay": opt.weight_decay, 'lr': opt.lr},
        {"params": [p for n, p in bert_param_optimizer if any(nd in n for nd in no_decay)],
         "weight_decay": 0.0, 'lr': opt.lr},

        # 其他模块，差分学习率
        {"params": [p for n, p in other_param_optimizer if not any(nd in n for nd in no_decay)],
         "weight_decay": opt.weight_decay, 'lr': opt.other_lr},
        {"params": [p for n, p in other_param_optimizer if any(nd in n for nd in no_decay)],
         "weight_decay": 0.0, 'lr': opt.other_lr},
    ]

    optimizer = AdamW(optimizer_grouped_parameters, lr=opt.lr, eps=opt.adam_epsilon)
    scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=int(opt.warmup_proportion * t_total), num_training_steps=t_total
    )

    return optimizer, scheduler


def model_evaluate(model,device,args):
    path = "./output/tmp_dev_predict_file.txt"
    with open(file=path,encoding="utf-8",mode="w") as f:
        data = json.load(open(args.valid_data, 'r', encoding='utf-8'))
        for item in tqdm(data):
            original_text = item["original_text"]
            res = model.predict([original_text],device)
            f.write("{}\t{}\t{}\n".format(original_text,item["correct_text"],res[0]))

    detect_f1, correct_f1, final_score = do_calculate(path)
    return detect_f1, correct_f1, final_score



def remove_pun(text):
    _text = ""
    for uchar in text:
        if uchar in en_pun + zh_pun + " 　":
            continue
        _text += uchar
    return _text


def read_input_file(input_file):
    pid_to_text = {}
    with open(input_file, "r") as f:
        for id, line in enumerate(f):
            line = line.strip().split("\t")
            line = [remove_pun(item.strip()) for item in line]
            pid = str(id)
            text = line[0]
            pid_to_text[pid] = text
    return pid_to_text


def read_label_file(pid_to_text, label_file_list):
    """
    读取纠正结果
    :param filename:
    :return:
    """
    error_set, det_set, cor_set = set(), set(), set()
    for line in label_file_list:
        terms = line.strip().split(",")
        terms = [t.strip() for t in terms]
        pid = terms[0]
        if pid not in pid_to_text:
            continue
        if len(terms) == 2 and terms[-1] == "-1":
            continue
        text = pid_to_text[pid]
        if (len(terms) - 2) % 4 == 0:
            error_num = int((len(terms) - 2) / 4)
            for i in range(error_num):
                loc, typ, wrong, correct = terms[i * 4 + 1 : (i + 1) * 4 + 1]
                loc = int(loc)
                cor_text = text[:loc] + correct + text[loc + len(wrong) :]
                error_set.add((pid, loc, wrong, cor_text))
                det_set.add((pid, loc, wrong))
                cor_set.add((pid, cor_text))
        else:
            raise Exception("check your data format: {}".format(line))
    # assert len(error_set) == len(det_set) == len(cor_set)
    return error_set, det_set, cor_set


def cal_f1(ref_num, pred_num, right_num):
    precision = float(right_num) / (pred_num + 0.0001)
    recall = float(right_num) / (ref_num + 0.0001)
    if precision + recall < 1e-6:
        return 0.0
    f1 = 2 * precision * recall / (precision + recall + 0.0001)
    return f1 * 100


def evaluate(input_file, ref_file_list, pred_file_list):
    pid_to_text = read_input_file(input_file)
    ref_error_set, ref_det_set, ref_cor_set = read_label_file(pid_to_text, ref_file_list)
    pred_error_set, pred_det_set, pred_cor_set = read_label_file(pid_to_text, pred_file_list)

    ref_num = len(ref_cor_set)
    pred_num = len(pred_cor_set)

    det_right_num = 0
    for error in ref_error_set:
        pid, loc, wrong, cor_text = error
        if (pid, loc, wrong) in pred_det_set or (pid, cor_text) in pred_cor_set:
            det_right_num += 1
    detect_f1 = cal_f1(ref_num, pred_num, det_right_num)

    cor_right_num = len(ref_cor_set & pred_cor_set)
    correct_f1 = cal_f1(ref_num, pred_num, cor_right_num)

    final_score = 0.8 * detect_f1 + 0.2 * correct_f1
    return detect_f1, correct_f1, final_score


def convert_from_sentpair2edits(lines_sid, lines_src, lines_tgt):
    assert len(lines_src) == len(lines_tgt) == len(lines_sid)
    convert_result = []
    for i in range(len(lines_src)):
        src_line = lines_src[i].strip()
        tgt_line = lines_tgt[i].strip()
        sid = lines_sid[i].strip()
        edits = Levenshtein.opcodes(src_line, tgt_line)
        result = []
        for edit in edits:
            if "。" in tgt_line[edit[3] : edit[4]]:
                continue
            if edit[0] == "insert":
                result.append((str(edit[1]), "缺失", "", tgt_line[edit[3] : edit[4]]))
            elif edit[0] == "replace":
                result.append((str(edit[1]), "别字", src_line[edit[1] : edit[2]], tgt_line[edit[3] : edit[4]]))
            elif edit[0] == "delete":
                result.append((str(edit[1]), "冗余", src_line[edit[1] : edit[2]], ""))

        out_line = ""
        for res in result:
            out_line += ", ".join(res) + ", "
        if out_line:
            convert_result.append(sid + ", " + out_line.strip())
        else:
            convert_result.append(sid + ", -1")
    return convert_result


def do_calculate(path):
    pred_map = {}
    pred_id, pred_src, pred_prd = [], [], []
    with open(path) as f:
        for idx, line in enumerate(f):
            line = line.lower().split("\t")
            if len(line) != 3:
                raise ValueError("line {} length must be 3 after split by \\t, line: {}".format(idx, line))
            pred_id.append(str(idx))
            pred_src.append(remove_pun(line[0].strip()))
            pred_prd.append(remove_pun(line[2].strip()))
    pred_convert_result = convert_from_sentpair2edits(pred_id, pred_src, pred_prd)
    ref_id, ref_src, ref_prd = [], [], []
    with open(path) as f:
        for idx, line in enumerate(f):
            line = line.lower().split("\t")
            ref_id.append(str(idx))
            ref_src.append(remove_pun(line[0].strip()))
            ref_prd.append(remove_pun(line[1].strip()))
    ref_convert_result = convert_from_sentpair2edits(ref_id, ref_src, ref_prd)
    detect_f1, correct_f1, final_score = evaluate(path, ref_convert_result, pred_convert_result)
    return detect_f1, correct_f1, final_score


def save_model(opt, model,epoch):
    if not os.path.exists(opt.output_dir):
        os.makedirs(opt.output_dir, exist_ok=True)

    # take care of model distributed / parallel training
    model_to_save = (
        model.module if hasattr(model, "module") else model
    )
    torch.save(model_to_save.state_dict(), os.path.join(opt.output_dir,'best_model.pt'))